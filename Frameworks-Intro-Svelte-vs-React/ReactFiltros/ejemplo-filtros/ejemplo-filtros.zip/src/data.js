// src/data.js
export const games = [
  { id: 1, titulo: "The Witcher 3", genero: "RPG", plataforma: "PC", puntuacion: 9.5 },
  { id: 2, titulo: "Hades", genero: "Roguelike", plataforma: "PC", puntuacion: 9.0 },
  { id: 3, titulo: "Animal Crossing", genero: "Simulación", plataforma: "Switch", puntuacion: 8.5 },
  { id: 4, titulo: "Elden Ring", genero: "RPG", plataforma: "PC", puntuacion: 9.7 },
  { id: 5, titulo: "Mario Kart 8", genero: "Carreras", plataforma: "Switch", puntuacion: 8.8 },
  { id: 6, titulo: "God of War", genero: "Acción", plataforma: "PlayStation", puntuacion: 9.3 },
  { id: 7, titulo: "Stardew Valley", genero: "Simulación", plataforma: "PC", puntuacion: 8.9 },
];
